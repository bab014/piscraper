"""
Error module holds all custom errors
for the scraper class
"""


class InvalidWebsite(Exception):
    """
    An Invalid website was proided to the scraper
    """

    pass
