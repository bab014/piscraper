# WebScraper

### Purpose
To scrape the web and find when a Raspberry Pi is available
